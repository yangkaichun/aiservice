
const config = {
    API_URL: "https://script.google.com/macros/s/AKfycbzIWVf-agx4yX10KvLL1QtIsDpzM_2pT24mQK99juHCKctycVzciuCU7pSCXsuikARJIQ/exec"
};